var likes = document.querySelectorAll(".like"),
    main = document.querySelector("main"),
    login = document.querySelectorAll(".aanmelden button, fieldset > button");


// LIKE BUTTON

if (likes[0]) {
    for (var i = 0; i < likes.length; i++) {
        likes[i].addEventListener("click", function () {
            var that = this,
                span = that.querySelector("span"),
                num = parseInt(span.innerHTML);

            num += 1;
            span.innerHTML = num;
            that.querySelector("svg").classList.add("big");
            setTimeout(function () {
                that.querySelector("svg").classList.remove("big");
            }, 300);
        });
    }
}

// LIKE BUTTON END

// ACCOUNT AANMAKEN

if (document.querySelectorAll("main article div.aanmelden")[0]) {
    for (var i = 0; i < login.length; i++) {
        login[i].addEventListener("click", function (event) {
            event.preventDefault();
            var allForm = document.querySelectorAll("main article > form"),
                aanmaken = document.querySelectorAll(".aanmelden")[0];
            aanmaken.style.display = "none";
            allForm[0].style.display = "none";
            allForm[1].style.display = "none";
            document.querySelectorAll("main article > h1")[0].style.display = "none";
            this.innerHTML == "Annuleren" ? aanmaken.style.display = "block" : allForm[1].style.display = "block";
            this.innerHTML == "Annuleren" ? allForm[0].style.display = "block" : "";
            this.innerHTML == "Annuleren" ? document.querySelectorAll("main article > h1")[0].style.display = "block" : "";
        });
    }
}

// ACCOUNT AANMAKEN END